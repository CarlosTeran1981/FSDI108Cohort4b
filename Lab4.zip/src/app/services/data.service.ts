import { Injectable } from '@angular/core';
import { user } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  userList: user[] = [];

  constructor() {}

  public sayHello(){
    console.log('Hello Fools');
  }

  public addUser(userVal: user) {
    this.userList.push(userVal);
  }

  public getAllUsers(){
    return this.userList;
  }
}
